#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;

struct nationalParkData {
 string  parkName;
 string  state;
 int yearlyVisits;
 double squareAcres;
 int parkCap = 59;
};

struct backendInput{
	char firstChoice;
	bool valid = true;
	string inputState;
	string deletePark;
};


struct states {
		string arrstate[51] = {"Alaska","Alabama","Arkansas","Arizona","California","Colorado","Connecticut","District of Columbia","Delaware","Florida","Georgia","Hawaii","Iowa","Idaho","Illinois","Indiana","Kansas","Kentucky","Louisiana","Massachusetts","Maryland","Maine","Michigan","Minnesota","Missouri","Mississippi","Montana","North Carolina","North Dakota","Nebraska","New Hampshire","New Jersey","New Mexico","Nevada","New York","Ohio","Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah","Virginia","Vermont","Washington","Wisconsin","West Virginia","Wyoming"};

	nationalParkData Alaska[10];
	nationalParkData Alabama[10];
	nationalParkData Arkansas[10];
	nationalParkData Arizona[10];
	nationalParkData California[10];
	nationalParkData Colorado[10];
	nationalParkData Connecticut[10];
	nationalParkData DistrictOfColumbia[10];
	nationalParkData Delaware[10];
	nationalParkData Florida[10];
	nationalParkData Georgia[10];
	nationalParkData Hawaii[10];
	nationalParkData Iowa[10];
	nationalParkData Idaho[10];
	nationalParkData Illinois[10];
	nationalParkData Indiana[10];
	nationalParkData Kansas[10];
	nationalParkData Kentucky[10];
	nationalParkData Louisiana[10];
	nationalParkData Massachusetts[10];
	nationalParkData Maryland[10];
	nationalParkData Maine[10];
	nationalParkData Michigan[10];
	nationalParkData Minnesota[10];
	nationalParkData Missouri[10];
	nationalParkData Mississippi[10];
	nationalParkData Montana[10];
	nationalParkData NorthCarolina[10];
	nationalParkData NorthDakota[10];
	nationalParkData Nebraska[10];
	nationalParkData NewHampshire[10];
	nationalParkData NewJersey[10];
	nationalParkData NewMexico[10];
	nationalParkData Nevada[10];
	nationalParkData NewYork[10];
	nationalParkData Ohio[10];
	nationalParkData Oklahoma[10];
	nationalParkData Oregon[10];
	nationalParkData Pennsylvania[10];
	nationalParkData RhodeIsland[10];
	nationalParkData SouthCarolina[10];
	nationalParkData SouthDakota[10];
	nationalParkData Tennessee[10];
	nationalParkData Texas[10];
	nationalParkData Utah[10];
	nationalParkData Virginia[10];
	nationalParkData Vermont[10];
	nationalParkData Washington[10];
	nationalParkData Wisconsin[10];
	nationalParkData WestVirginia[10];
	nationalParkData Wyoming[10];
};

void introduction();

bool collectData (nationalParkData n,nationalParkData parkarr[],int& c);

void display (const nationalParkData parkarr[],int c);

void switchChoice (backendInput q,nationalParkData n,nationalParkData parkarr[],states s);

void stateSort( nationalParkData parkarr[], states s,backendInput q);

void remove(nationalParkData parkarr[],nationalParkData n,backendInput q);