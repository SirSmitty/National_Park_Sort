#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include"library.h"
using namespace std;

void introduction(){
	cout <<"This program allows you to sort multiple data scenarios in regards to our beautiful Natioanl Parks and will allow you to create a list containing your 10 most desired destinations. the list is generated from the following link :\n https://github.com/joshuakemmerling/AwesomeData/blob/master/national-parks.csv \nThe criteria you are able to order is as follows : \n\nParks of Certain national regions \t\t yearly visits \t\t Squre miles of Parks" << endl;
}

bool collectData (nationalParkData n,nationalParkData parkarr[],int& c) {
	c = 0;
	ifstream inputFile("input.dat");
		if (inputFile.is_open() == false){
	cout <<"This file is unable to be read" << endl;
	} //end of if
	while (!inputFile.eof()){
		getline(inputFile,n.parkName,',');
		getline(inputFile,n.state,',');
		inputFile >> n.yearlyVisits;
		inputFile.ignore();
		inputFile >> n.squareAcres;
		inputFile.ignore();
		parkarr[c] = {n.parkName,n.state,n.yearlyVisits,n.squareAcres};
		c++;
	}
	return true;
}

void display (const nationalParkData parkarr[],int c){
	for (int i = 0;i < c ; i++){
		cout <<left << setw(30) << parkarr[i].parkName 
		<< setw(20)<< parkarr[i].state
		<< setw(20) << parkarr[i].yearlyVisits
		<< setw(20) << parkarr[i].squareAcres <<right << setw(30) << endl;
	} // end of for loop display
}

void stateSort(nationalParkData parkarr[],states s,backendInput q){
	int AK = 0,AL = 0,AR = 0,AZ = 0,CA = 0,CO = 0,CT = 0,DE = 0,DC = 0,FL = 0,GA = 0,HI = 0,ID = 0,IL = 0,IN = 0,IA = 0,KS = 0,KY = 0,LA = 0,ME = 0,MD = 0,MA = 0,MI = 0,MN = 0,MS = 0,MO = 0,MT = 0,NE = 0,NV = 0,NH = 0,NJ = 0,NM = 0,NY = 0,NC = 0,ND = 0,OH = 0,OK = 0,OR = 0,PA = 0,RI = 0,SC = 0,SD = 0,TN = 0,TX = 0,UT = 0,VT = 0,VA = 0,WA = 0,WV = 0,WI = 0,WY = 0;

		for (int j = 0; j < 62; j++){
			//alaska
			if (s.arrstate[0] == parkarr[j].state){
				s.Alaska[AK] = parkarr[j];
				AK++;		 
			}
			//Alabama
			if (s.arrstate[1] == parkarr[j].state){
				s.Alabama[AL] = parkarr[j];
				AL++;
			}
			//Arkansas
			if (s.arrstate[2] == parkarr[j].state){
				s.Arkansas[AR] = parkarr[j];
				AR++;
			}
			//Arizona
			if (s.arrstate[3] == parkarr[j].state){
				s.Arizona[AZ] = parkarr[j];
				AZ++;
			}
			//california
			if (s.arrstate[4] == parkarr[j].state){
				s.California[CA] = parkarr[j];
				CA++;
			}
			//Colorado
			if (s.arrstate[5] == parkarr[j].state){
				s.Colorado[CO] = parkarr[j];
				CO++;
			}
			//Connecticut
			if (s.arrstate[6] == parkarr[j].state){
				s.Connecticut[CT] = parkarr[j];
				CT++;
			}
			//District of Columbia
			if (s.arrstate[7] == parkarr[j].state){
				s.DistrictOfColumbia[DC] = parkarr[j];
				DC++;
			}
			// Delaware
			if (s.arrstate[8] == parkarr[j].state){
				s.Delaware[DE] = parkarr[j];
				DE++;
			}
			//Florida
			if (s.arrstate[9] == parkarr[j].state){
				s.Florida[FL] = parkarr[j];
				FL++;
			}
			//Georgia
			if (s.arrstate[10] == parkarr[j].state){
				s.Georgia[GA] = parkarr[j];
				GA++;
			}
			//Hawaii
			if (s.arrstate[11] == parkarr[j].state){
				s.Hawaii[HI] = parkarr[j];
				HI++;
			}
			//Iowa
			if (s.arrstate[12] == parkarr[j].state){
				s.Iowa[IA] = parkarr[j];
				IA++;
			}
			//Idaho
			if (s.arrstate[13] == parkarr[j].state){
				s.Idaho[ID] = parkarr[j];
				ID++;
			}
			//Illinois
			if (s.arrstate[14] == parkarr[j].state){
				s.Illinois[IL] = parkarr[j];
				IL++;
			}
			//Indiana
			if (s.arrstate[15] == parkarr[j].state){
				s.Indiana[IN] = parkarr[j];
				IN++;
			}
			//Kansas
			if (s.arrstate[16] == parkarr[j].state){
				s.Kansas[KS] = parkarr[j];
				KS++;
			}
			//Kentucky
			if (s.arrstate[17] == parkarr[j].state){
				s.Kentucky[KY] = parkarr[j];
				KY++;
			}
			//Louisiana
			if (s.arrstate[18] == parkarr[j].state){
				s.Louisiana[LA] = parkarr[j];
				LA++;
			}  
			//Massachusetts 
			if (s.arrstate[19] == parkarr[j].state){
				s.Massachusetts[MA] = parkarr[j];
				MA++;
			} 
			//Maryland
			if (s.arrstate[20] == parkarr[j].state){
				s.Maryland[MD] = parkarr[j];
				MD++;
			} 
			//Maine
			if (s.arrstate[21] == parkarr[j].state){
				s.Maine[ME] = parkarr[j];
				ME++;
			} 
			//Michigan
			if (s.arrstate[22] == parkarr[j].state){
				s.Michigan[MI] = parkarr[j];
				MI++;
			} 
			//Minnesota
			if (s.arrstate[23] == parkarr[j].state){
				s.Maine[ME] = parkarr[j];
				MN++;
			} 
			//Missouri
			if (s.arrstate[24] == parkarr[j].state){
				s.Missouri[MO] = parkarr[j];
				MO++;
			} 
			//Mississippi
			if (s.arrstate[25] == parkarr[j].state){
				s.Mississippi[MS] = parkarr[j];
				MS++;
			} 
			//Montana
			if (s.arrstate[26] == parkarr[j].state){
				s.Montana[MT] = parkarr[j];
				MT++;
			} 
			//North Carolina
			if (s.arrstate[27] == parkarr[j].state){
				s.NorthCarolina[NC] = parkarr[j];
				NC++;
			} 
			//North Dakota
			if (s.arrstate[28] == parkarr[j].state){
				s.NorthDakota[ND] = parkarr[j];
				ND++;
			} 
			//Nebraska
			if (s.arrstate[29] == parkarr[j].state){
				s.Nebraska[NE] = parkarr[j];
				NE++;
			} 
			//New Hampshire
			if (s.arrstate[30] == parkarr[j].state){
				s.NewHampshire[NH] = parkarr[j];
				NH++;
			} 
			//New Jersey
			if (s.arrstate[31] == parkarr[j].state){
				s.NewJersey[NJ] = parkarr[j];
				NJ++;
			} 
			//New Mexico
			if (s.arrstate[32] == parkarr[j].state){
				s.NewMexico[NM] = parkarr[j];
				NM++;
			} 
			//Nevada
			if (s.arrstate[33] == parkarr[j].state){
				s.Nevada[NV] = parkarr[j];
				NV++;
			} 
			//New York
			if (s.arrstate[34] == parkarr[j].state){
				s.NewYork[NY] = parkarr[j];
				NY++;
			} 
			//Ohio
			if (s.arrstate[35] == parkarr[j].state){
				s.Ohio[OH] = parkarr[j];
				OH++;
			} 
			//Oklahoma
			if (s.arrstate[36] == parkarr[j].state){
				s.Oklahoma[OK] = parkarr[j];
				OK++;
			} 
			//Oregon
			if (s.arrstate[37] == parkarr[j].state){
				s.Oregon[OR] = parkarr[j];
				OR++;
			} 
			//Pennsylvania
			if (s.arrstate[38] == parkarr[j].state){
				s.Pennsylvania[PA] = parkarr[j];
				PA++;
			} 
			//Rhode Island
			if (s.arrstate[39] == parkarr[j].state){
				s.RhodeIsland[RI] = parkarr[j];
				RI++;
			} 
			//South Carolina
			if (s.arrstate[40] == parkarr[j].state){
				s.SouthCarolina[SC] = parkarr[j];
				SC++;
			} 
			//South Dakota
			if (s.arrstate[41] == parkarr[j].state){
				s.SouthDakota[SD] = parkarr[j];
				SD++;
			} 
			//Tennessee
			if (s.arrstate[42] == parkarr[j].state){
				s.Tennessee[TN] = parkarr[j];
				TN++;
			} 
			//Texas
			if (s.arrstate[43] == parkarr[j].state){
				s.Texas[TX] = parkarr[j];
				TX++;
			} 
			// Utah
			if (s.arrstate[44] == parkarr[j].state){
				s.Utah[UT] = parkarr[j];
				UT++;
			} 
			//Virginia
			if (s.arrstate[45] == parkarr[j].state){
				s.Virginia[VA] = parkarr[j];
				VA++;
			} 
			//Vermont
			if (s.arrstate[46] == parkarr[j].state){
				s.Vermont[VT] = parkarr[j];
				VT++;
			} 
			//Washington
			if (s.arrstate[47] == parkarr[j].state){
				s.Washington[WA] = parkarr[j];
				WA++;
			} 
			//Wisconsin
			if (s.arrstate[48] == parkarr[j].state){
				s.Wisconsin[WI] = parkarr[j];
				WI++;
			} 
			//West Virginia
			if (s.arrstate[49] == parkarr[j].state){
				s.WestVirginia[WV] = parkarr[j];
				WV++;
			} 
			//Wyoming
			if (s.arrstate[50] == parkarr[j].state){
				s.Wyoming[WY] = parkarr[j];
				WY++;
			}	 
		} // end of for	
	
	cout <<"What state would you like to see? : ";
	cin >> q.inputState;
		/*   The following loop would go through all 59 parks but only display parks in the requested state.*/
  	for (int i = 0; i < 59; i++) {
    	if (parkarr[i].state == q.inputState) {
				cout <<left << setw(30) << parkarr[i].parkName 
				<< setw(20) << parkarr[i].state
				<< setw(20) << parkarr[i].yearlyVisits
				<< setw(20) << parkarr[i].squareAcres <<right << setw(30) << endl;
    }
  }
} // end of state sort

void remove(nationalParkData parkarr[],nationalParkData n,backendInput q){
	int index = 0;
	while (index < n.parkCap && parkarr[index].parkName != q.deletePark){
		index++;
	} //end of searching for the match
	if (index != n.parkCap){
		//match found 
		for (int i = index; i < (n.parkCap - 1) ; i++){
			parkarr[i] = parkarr[i+1];
		} //end of shifting elements forward
		n.parkCap--;
	}
	for (int i = 0 ; i < n.parkCap ; i++){
		cout <<left << setw(30) << parkarr[i].parkName 
		<< setw(20) << parkarr[i].state
		<< setw(20) << parkarr[i].yearlyVisits
		<< setw(20) << parkarr[i].squareAcres <<right << setw(30) << endl;		
	}
}

void switchChoice (backendInput q,nationalParkData n,nationalParkData parkarr[],states s){
	nationalParkData temp;
	bool valid = true;
	
	do{
		cout <<"\nAfter seeing all of the data collected, how would you like to sort it? :" << endl <<"A. Least visited to most visited" << endl <<"B. Smallest park to largest" << endl <<"C. Grouped by states" << endl <<"D. Delete park from list" << endl << "E. End Program" << endl;

		cout <<"Please enter your answer : ";
		cin >> q.firstChoice;
		switch (q.firstChoice){	
			case 'A' :
				valid = false;
				cout <<"You chose A" << endl;
				for(int i=0;i<n.parkCap;i++){		
					for(int j=i+1;j < n.parkCap;j++){
						if(parkarr[i].yearlyVisits>parkarr[j].yearlyVisits){
							temp = parkarr[i];
							parkarr[i]=parkarr[j];
							parkarr[j]=temp;
						} //end of if
					} // end of second for
				} //end of main for
				display(parkarr, n.parkCap);
				break;
			case 'B' :
				valid = false;
				cout <<"You chose B" <<endl;
				for(int i=0;i<n.parkCap;i++){		
					for(int j=i+1;j < n.parkCap;j++){
						if(parkarr[i].squareAcres > parkarr[j].squareAcres){
							temp = parkarr[i];
							parkarr[i]=parkarr[j];
							parkarr[j]=temp;
						} //end of if
					} // end of second for
				} // end of main for
				display(parkarr, n.parkCap);
				break;
			case 'C' :
				valid = false;
				cout <<"You chose C" << endl;
				stateSort(parkarr, s, q);
				break; //break for choice c
			case 'D' :
				valid = false;
				cout <<"Which park would you like to delete from the list? Please enter the park name : " << endl;
				cin >> q.deletePark;
				remove(parkarr,n,q);
				break;
			case 'E' :
				valid = true;
				cout <<"You have chosen to end the program";				
			}// end of switch
	}while(!valid);
} // end of switch choice

