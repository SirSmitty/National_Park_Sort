#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "library.h"
using namespace std;

int main() {
	//declares neccessary variables
	backendInput b;
	nationalParkData n;
	states s;
	backendInput q;
	int fileSize = 0;
	
	nationalParkData parkarr[n.parkCap];
	
	introduction();

	collectData(n, parkarr,fileSize); // collects data into parkarr

	display(parkarr, fileSize); // displays data of array into 4 columns.

	switchChoice(q,n,parkarr,s); //take sinput from user to decide which sorting alg. to 																execute
	
} //end of main